﻿namespace GenericRPG
{
    partial class FrmShop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.picInv3Tip = new System.Windows.Forms.ToolTip(this.components);
            this.picInv1Tip = new System.Windows.Forms.ToolTip(this.components);
            this.picInv0Tip = new System.Windows.Forms.ToolTip(this.components);
            this.weaponTip = new System.Windows.Forms.ToolTip(this.components);
            this.lblWeapon = new System.Windows.Forms.Label();
            this.picInv2Tip = new System.Windows.Forms.ToolTip(this.components);
            this.picInv0 = new System.Windows.Forms.PictureBox();
            this.picInv1 = new System.Windows.Forms.PictureBox();
            this.picInv2 = new System.Windows.Forms.PictureBox();
            this.picInv3 = new System.Windows.Forms.PictureBox();
            this.picInv4 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.picInv4Tip = new System.Windows.Forms.ToolTip(this.components);
            this.coinBox = new System.Windows.Forms.PictureBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblCharGb = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picInv0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInv1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInv2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInv3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInv4)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.coinBox)).BeginInit();
            this.SuspendLayout();
            // 
            // lblWeapon
            // 
            this.lblWeapon.AutoSize = true;
            this.lblWeapon.Location = new System.Drawing.Point(19, 69);
            this.lblWeapon.Name = "lblWeapon";
            this.lblWeapon.Size = new System.Drawing.Size(0, 13);
            this.lblWeapon.TabIndex = 8;
            // 
            // picInv0
            // 
            this.picInv0.Location = new System.Drawing.Point(5, 5);
            this.picInv0.Name = "picInv0";
            this.picInv0.Size = new System.Drawing.Size(85, 63);
            this.picInv0.TabIndex = 0;
            this.picInv0.TabStop = false;
            // 
            // picInv1
            // 
            this.picInv1.Location = new System.Drawing.Point(98, 5);
            this.picInv1.Name = "picInv1";
            this.picInv1.Size = new System.Drawing.Size(85, 63);
            this.picInv1.TabIndex = 1;
            this.picInv1.TabStop = false;
            // 
            // picInv2
            // 
            this.picInv2.Location = new System.Drawing.Point(191, 5);
            this.picInv2.Name = "picInv2";
            this.picInv2.Size = new System.Drawing.Size(85, 63);
            this.picInv2.TabIndex = 2;
            this.picInv2.TabStop = false;
            // 
            // picInv3
            // 
            this.picInv3.Location = new System.Drawing.Point(284, 5);
            this.picInv3.Name = "picInv3";
            this.picInv3.Size = new System.Drawing.Size(85, 63);
            this.picInv3.TabIndex = 3;
            this.picInv3.TabStop = false;
            // 
            // picInv4
            // 
            this.picInv4.Location = new System.Drawing.Point(377, 5);
            this.picInv4.Name = "picInv4";
            this.picInv4.Size = new System.Drawing.Size(86, 63);
            this.picInv4.TabIndex = 4;
            this.picInv4.TabStop = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Silver;
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Outset;
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Controls.Add(this.picInv0, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.picInv1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.picInv2, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.picInv3, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.picInv4, 4, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 69);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(468, 375);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // coinBox
            // 
            this.coinBox.Location = new System.Drawing.Point(12, 7);
            this.coinBox.Name = "coinBox";
            this.coinBox.Size = new System.Drawing.Size(57, 53);
            this.coinBox.TabIndex = 9;
            this.coinBox.TabStop = false;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(400, 7);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 10;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblCharGb
            // 
            this.lblCharGb.AutoSize = true;
            this.lblCharGb.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lblCharGb.ForeColor = System.Drawing.Color.Gold;
            this.lblCharGb.Location = new System.Drawing.Point(75, 21);
            this.lblCharGb.Name = "lblCharGb";
            this.lblCharGb.Size = new System.Drawing.Size(0, 26);
            this.lblCharGb.TabIndex = 11;
            // 
            // FrmShop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(499, 451);
            this.Controls.Add(this.lblCharGb);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.coinBox);
            this.Controls.Add(this.lblWeapon);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "FrmShop";
            this.Text = "FrmShop";
            ((System.ComponentModel.ISupportInitialize)(this.picInv0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInv1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInv2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInv3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInv4)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.coinBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolTip picInv3Tip;
        private System.Windows.Forms.ToolTip picInv1Tip;
        private System.Windows.Forms.ToolTip picInv0Tip;
        private System.Windows.Forms.ToolTip weaponTip;
        private System.Windows.Forms.Label lblWeapon;
        private System.Windows.Forms.ToolTip picInv2Tip;
        private System.Windows.Forms.PictureBox picInv0;
        private System.Windows.Forms.PictureBox picInv1;
        private System.Windows.Forms.PictureBox picInv2;
        private System.Windows.Forms.PictureBox picInv3;
        private System.Windows.Forms.PictureBox picInv4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.ToolTip picInv4Tip;
        private System.Windows.Forms.PictureBox coinBox;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblCharGb;
    }
}