﻿namespace GenericRPG {
  partial class FrmLevelUp {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing) {
      if (disposing && (components != null)) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.lblOldLevel = new System.Windows.Forms.Label();
      this.label6 = new System.Windows.Forms.Label();
      this.lblOldHealth = new System.Windows.Forms.Label();
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.lblOldStr = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.lblOldDef = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.lblOldMana = new System.Windows.Forms.Label();
      this.panel1 = new System.Windows.Forms.Panel();
      this.label16 = new System.Windows.Forms.Label();
      this.panel2 = new System.Windows.Forms.Panel();
      this.label17 = new System.Windows.Forms.Label();
      this.label5 = new System.Windows.Forms.Label();
      this.lblNewLevel = new System.Windows.Forms.Label();
      this.lblNewMana = new System.Windows.Forms.Label();
      this.label9 = new System.Windows.Forms.Label();
      this.lblNewHealth = new System.Windows.Forms.Label();
      this.lblNewDef = new System.Windows.Forms.Label();
      this.label12 = new System.Windows.Forms.Label();
      this.label13 = new System.Windows.Forms.Label();
      this.label14 = new System.Windows.Forms.Label();
      this.lblNewStr = new System.Windows.Forms.Label();
      this.btnClose = new System.Windows.Forms.Button();
      this.pictureBox1 = new System.Windows.Forms.PictureBox();
      this.panel1.SuspendLayout();
      this.panel2.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
      this.SuspendLayout();
      // 
      // lblOldLevel
      // 
      this.lblOldLevel.AutoSize = true;
      this.lblOldLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblOldLevel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
      this.lblOldLevel.Location = new System.Drawing.Point(99, 59);
      this.lblOldLevel.Name = "lblOldLevel";
      this.lblOldLevel.Size = new System.Drawing.Size(85, 29);
      this.lblOldLevel.TabIndex = 23;
      this.lblOldLevel.Text = "label1";
      // 
      // label6
      // 
      this.label6.AutoSize = true;
      this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
      this.label6.Location = new System.Drawing.Point(11, 59);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(83, 29);
      this.label6.TabIndex = 24;
      this.label6.Text = "Level:";
      this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // lblOldHealth
      // 
      this.lblOldHealth.AutoSize = true;
      this.lblOldHealth.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblOldHealth.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
      this.lblOldHealth.Location = new System.Drawing.Point(99, 104);
      this.lblOldHealth.Name = "lblOldHealth";
      this.lblOldHealth.Size = new System.Drawing.Size(85, 29);
      this.lblOldHealth.TabIndex = 15;
      this.lblOldHealth.Text = "label1";
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
      this.label1.Location = new System.Drawing.Point(11, 133);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(83, 29);
      this.label1.TabIndex = 22;
      this.label1.Text = "Mana:";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
      this.label2.Location = new System.Drawing.Point(34, 205);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(60, 29);
      this.label2.TabIndex = 21;
      this.label2.Text = "Def:";
      this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // lblOldStr
      // 
      this.lblOldStr.AutoSize = true;
      this.lblOldStr.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblOldStr.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
      this.lblOldStr.Location = new System.Drawing.Point(99, 177);
      this.lblOldStr.Name = "lblOldStr";
      this.lblOldStr.Size = new System.Drawing.Size(85, 29);
      this.lblOldStr.TabIndex = 16;
      this.lblOldStr.Text = "label1";
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
      this.label3.Location = new System.Drawing.Point(41, 177);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(53, 29);
      this.label3.TabIndex = 20;
      this.label3.Text = "Str:";
      this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // lblOldDef
      // 
      this.lblOldDef.AutoSize = true;
      this.lblOldDef.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblOldDef.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
      this.lblOldDef.Location = new System.Drawing.Point(99, 205);
      this.lblOldDef.Name = "lblOldDef";
      this.lblOldDef.Size = new System.Drawing.Size(85, 29);
      this.lblOldDef.TabIndex = 17;
      this.lblOldDef.Text = "label1";
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
      this.label4.Location = new System.Drawing.Point(-1, 104);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(95, 29);
      this.label4.TabIndex = 19;
      this.label4.Text = "Health:";
      this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // lblOldMana
      // 
      this.lblOldMana.AutoSize = true;
      this.lblOldMana.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblOldMana.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
      this.lblOldMana.Location = new System.Drawing.Point(99, 133);
      this.lblOldMana.Name = "lblOldMana";
      this.lblOldMana.Size = new System.Drawing.Size(85, 29);
      this.lblOldMana.TabIndex = 18;
      this.lblOldMana.Text = "label1";
      // 
      // panel1
      // 
      this.panel1.BackColor = System.Drawing.Color.Transparent;
      this.panel1.Controls.Add(this.label16);
      this.panel1.Controls.Add(this.label6);
      this.panel1.Controls.Add(this.lblOldLevel);
      this.panel1.Controls.Add(this.lblOldMana);
      this.panel1.Controls.Add(this.label4);
      this.panel1.Controls.Add(this.lblOldHealth);
      this.panel1.Controls.Add(this.lblOldDef);
      this.panel1.Controls.Add(this.label1);
      this.panel1.Controls.Add(this.label3);
      this.panel1.Controls.Add(this.label2);
      this.panel1.Controls.Add(this.lblOldStr);
      this.panel1.Location = new System.Drawing.Point(34, 105);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(185, 236);
      this.panel1.TabIndex = 25;
      // 
      // label16
      // 
      this.label16.AutoSize = true;
      this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label16.ForeColor = System.Drawing.Color.White;
      this.label16.Location = new System.Drawing.Point(29, 9);
      this.label16.Name = "label16";
      this.label16.Size = new System.Drawing.Size(135, 31);
      this.label16.TabIndex = 27;
      this.label16.Text = "Old Stats";
      // 
      // panel2
      // 
      this.panel2.BackColor = System.Drawing.Color.Transparent;
      this.panel2.Controls.Add(this.label17);
      this.panel2.Controls.Add(this.label5);
      this.panel2.Controls.Add(this.lblNewLevel);
      this.panel2.Controls.Add(this.lblNewMana);
      this.panel2.Controls.Add(this.label9);
      this.panel2.Controls.Add(this.lblNewHealth);
      this.panel2.Controls.Add(this.lblNewDef);
      this.panel2.Controls.Add(this.label12);
      this.panel2.Controls.Add(this.label13);
      this.panel2.Controls.Add(this.label14);
      this.panel2.Controls.Add(this.lblNewStr);
      this.panel2.Location = new System.Drawing.Point(537, 105);
      this.panel2.Name = "panel2";
      this.panel2.Size = new System.Drawing.Size(186, 234);
      this.panel2.TabIndex = 26;
      // 
      // label17
      // 
      this.label17.AutoSize = true;
      this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label17.ForeColor = System.Drawing.Color.White;
      this.label17.Location = new System.Drawing.Point(23, 9);
      this.label17.Name = "label17";
      this.label17.Size = new System.Drawing.Size(148, 31);
      this.label17.TabIndex = 28;
      this.label17.Text = "New Stats";
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
      this.label5.Location = new System.Drawing.Point(10, 59);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(83, 29);
      this.label5.TabIndex = 24;
      this.label5.Text = "Level:";
      this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // lblNewLevel
      // 
      this.lblNewLevel.AutoSize = true;
      this.lblNewLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblNewLevel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
      this.lblNewLevel.Location = new System.Drawing.Point(98, 59);
      this.lblNewLevel.Name = "lblNewLevel";
      this.lblNewLevel.Size = new System.Drawing.Size(85, 29);
      this.lblNewLevel.TabIndex = 23;
      this.lblNewLevel.Text = "label1";
      // 
      // lblNewMana
      // 
      this.lblNewMana.AutoSize = true;
      this.lblNewMana.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblNewMana.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
      this.lblNewMana.Location = new System.Drawing.Point(98, 133);
      this.lblNewMana.Name = "lblNewMana";
      this.lblNewMana.Size = new System.Drawing.Size(85, 29);
      this.lblNewMana.TabIndex = 18;
      this.lblNewMana.Text = "label1";
      // 
      // label9
      // 
      this.label9.AutoSize = true;
      this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
      this.label9.Location = new System.Drawing.Point(-2, 104);
      this.label9.Name = "label9";
      this.label9.Size = new System.Drawing.Size(95, 29);
      this.label9.TabIndex = 19;
      this.label9.Text = "Health:";
      this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // lblNewHealth
      // 
      this.lblNewHealth.AutoSize = true;
      this.lblNewHealth.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblNewHealth.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
      this.lblNewHealth.Location = new System.Drawing.Point(98, 104);
      this.lblNewHealth.Name = "lblNewHealth";
      this.lblNewHealth.Size = new System.Drawing.Size(85, 29);
      this.lblNewHealth.TabIndex = 15;
      this.lblNewHealth.Text = "label1";
      // 
      // lblNewDef
      // 
      this.lblNewDef.AutoSize = true;
      this.lblNewDef.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblNewDef.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
      this.lblNewDef.Location = new System.Drawing.Point(98, 205);
      this.lblNewDef.Name = "lblNewDef";
      this.lblNewDef.Size = new System.Drawing.Size(85, 29);
      this.lblNewDef.TabIndex = 17;
      this.lblNewDef.Text = "label1";
      // 
      // label12
      // 
      this.label12.AutoSize = true;
      this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
      this.label12.Location = new System.Drawing.Point(10, 133);
      this.label12.Name = "label12";
      this.label12.Size = new System.Drawing.Size(83, 29);
      this.label12.TabIndex = 22;
      this.label12.Text = "Mana:";
      this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // label13
      // 
      this.label13.AutoSize = true;
      this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
      this.label13.Location = new System.Drawing.Point(40, 177);
      this.label13.Name = "label13";
      this.label13.Size = new System.Drawing.Size(53, 29);
      this.label13.TabIndex = 20;
      this.label13.Text = "Str:";
      this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // label14
      // 
      this.label14.AutoSize = true;
      this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
      this.label14.Location = new System.Drawing.Point(33, 205);
      this.label14.Name = "label14";
      this.label14.Size = new System.Drawing.Size(60, 29);
      this.label14.TabIndex = 21;
      this.label14.Text = "Def:";
      this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // lblNewStr
      // 
      this.lblNewStr.AutoSize = true;
      this.lblNewStr.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblNewStr.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
      this.lblNewStr.Location = new System.Drawing.Point(98, 177);
      this.lblNewStr.Name = "lblNewStr";
      this.lblNewStr.Size = new System.Drawing.Size(85, 29);
      this.lblNewStr.TabIndex = 16;
      this.lblNewStr.Text = "label1";
      // 
      // btnClose
      // 
      this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnClose.Location = new System.Drawing.Point(317, 29);
      this.btnClose.Name = "btnClose";
      this.btnClose.Size = new System.Drawing.Size(159, 33);
      this.btnClose.TabIndex = 27;
      this.btnClose.Text = "Ok, I get it";
      this.btnClose.UseVisualStyleBackColor = true;
      this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
      // 
      // pictureBox1
      // 
      this.pictureBox1.Image = global::GenericRPG.Properties.Resources.character_levelup_animation;
      this.pictureBox1.Location = new System.Drawing.Point(1, 0);
      this.pictureBox1.Name = "pictureBox1";
      this.pictureBox1.Size = new System.Drawing.Size(801, 583);
      this.pictureBox1.TabIndex = 28;
      this.pictureBox1.TabStop = false;
      // 
      // FrmLevelUp
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.Color.Black;
      this.BackgroundImage = global::GenericRPG.Properties.Resources.character_levelup;
      this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
      this.ClientSize = new System.Drawing.Size(804, 582);
      this.Controls.Add(this.btnClose);
      this.Controls.Add(this.panel2);
      this.Controls.Add(this.panel1);
      this.Controls.Add(this.pictureBox1);
      this.Name = "FrmLevelUp";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Level Up!!";
      this.Load += new System.EventHandler(this.FrmLevelUp_Load);
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      this.panel2.ResumeLayout(false);
      this.panel2.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
      this.ResumeLayout(false);

    }

    #endregion
    private System.Windows.Forms.Label lblOldLevel;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.Label lblOldHealth;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label lblOldStr;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label lblOldDef;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label lblOldMana;
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.Label label16;
    private System.Windows.Forms.Panel panel2;
    private System.Windows.Forms.Label label17;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Label lblNewLevel;
    private System.Windows.Forms.Label lblNewMana;
    private System.Windows.Forms.Label label9;
    private System.Windows.Forms.Label lblNewHealth;
    private System.Windows.Forms.Label lblNewDef;
    private System.Windows.Forms.Label label12;
    private System.Windows.Forms.Label label13;
    private System.Windows.Forms.Label label14;
    private System.Windows.Forms.Label lblNewStr;
    private System.Windows.Forms.Button btnClose;
    private System.Windows.Forms.PictureBox pictureBox1;
  }
}