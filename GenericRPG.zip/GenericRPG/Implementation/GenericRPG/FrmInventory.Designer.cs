﻿namespace GenericRPG
{
    partial class FrmInventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.picInv0 = new System.Windows.Forms.PictureBox();
            this.picInv1 = new System.Windows.Forms.PictureBox();
            this.picInv2 = new System.Windows.Forms.PictureBox();
            this.picInv3 = new System.Windows.Forms.PictureBox();
            this.picInv4 = new System.Windows.Forms.PictureBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblWeapon = new System.Windows.Forms.Label();
            this.weaponTip = new System.Windows.Forms.ToolTip(this.components);
            this.picInv0Tip = new System.Windows.Forms.ToolTip(this.components);
            this.picInv1Tip = new System.Windows.Forms.ToolTip(this.components);
            this.picInv2Tip = new System.Windows.Forms.ToolTip(this.components);
            this.picInv3Tip = new System.Windows.Forms.ToolTip(this.components);
            this.picInv4Tip = new System.Windows.Forms.ToolTip(this.components);
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.picWeapon = new System.Windows.Forms.PictureBox();
            this.lblHeadgear = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picInv0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInv1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInv2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInv3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInv4)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picWeapon)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Silver;
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Outset;
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Controls.Add(this.picInv0, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.picInv1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.picInv2, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.picInv3, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.picInv4, 4, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 157);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(460, 292);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // picInv0
            // 
            this.picInv0.Location = new System.Drawing.Point(5, 5);
            this.picInv0.Name = "picInv0";
            this.picInv0.Size = new System.Drawing.Size(83, 50);
            this.picInv0.TabIndex = 0;
            this.picInv0.TabStop = false;
            // 
            // picInv1
            // 
            this.picInv1.Location = new System.Drawing.Point(96, 5);
            this.picInv1.Name = "picInv1";
            this.picInv1.Size = new System.Drawing.Size(83, 50);
            this.picInv1.TabIndex = 1;
            this.picInv1.TabStop = false;
            // 
            // picInv2
            // 
            this.picInv2.Location = new System.Drawing.Point(187, 5);
            this.picInv2.Name = "picInv2";
            this.picInv2.Size = new System.Drawing.Size(83, 50);
            this.picInv2.TabIndex = 2;
            this.picInv2.TabStop = false;
            // 
            // picInv3
            // 
            this.picInv3.Location = new System.Drawing.Point(278, 5);
            this.picInv3.Name = "picInv3";
            this.picInv3.Size = new System.Drawing.Size(83, 50);
            this.picInv3.TabIndex = 3;
            this.picInv3.TabStop = false;
            // 
            // picInv4
            // 
            this.picInv4.Location = new System.Drawing.Point(369, 5);
            this.picInv4.Name = "picInv4";
            this.picInv4.Size = new System.Drawing.Size(83, 50);
            this.picInv4.TabIndex = 4;
            this.picInv4.TabStop = false;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(397, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 2;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblWeapon
            // 
            this.lblWeapon.AutoSize = true;
            this.lblWeapon.Location = new System.Drawing.Point(11, 74);
            this.lblWeapon.Name = "lblWeapon";
            this.lblWeapon.Size = new System.Drawing.Size(0, 13);
            this.lblWeapon.TabIndex = 3;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.AllowDrop = true;
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.Silver;
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Outset;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.picWeapon, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(12, 90);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(184, 61);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // picWeapon
            // 
            this.picWeapon.Location = new System.Drawing.Point(5, 5);
            this.picWeapon.Name = "picWeapon";
            this.picWeapon.Size = new System.Drawing.Size(83, 50);
            this.picWeapon.TabIndex = 0;
            this.picWeapon.TabStop = false;
            // 
            // lblHeadgear
            // 
            this.lblHeadgear.AutoSize = true;
            this.lblHeadgear.Location = new System.Drawing.Point(103, 74);
            this.lblHeadgear.Name = "lblHeadgear";
            this.lblHeadgear.Size = new System.Drawing.Size(54, 13);
            this.lblHeadgear.TabIndex = 4;
            this.lblHeadgear.Text = "Headgear";
            // 
            // FrmInventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.GrayText;
            this.ClientSize = new System.Drawing.Size(484, 461);
            this.Controls.Add(this.lblHeadgear);
            this.Controls.Add(this.lblWeapon);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "FrmInventory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Inventory";
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picInv0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInv1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInv2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInv3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInv4)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picWeapon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblWeapon;
        private System.Windows.Forms.PictureBox picInv0;
        private System.Windows.Forms.ToolTip weaponTip;
        private System.Windows.Forms.PictureBox picInv1;
        private System.Windows.Forms.PictureBox picInv2;
        private System.Windows.Forms.PictureBox picInv3;
        private System.Windows.Forms.PictureBox picInv4;
        private System.Windows.Forms.ToolTip picInv0Tip;
        private System.Windows.Forms.ToolTip picInv1Tip;
        private System.Windows.Forms.ToolTip picInv2Tip;
        private System.Windows.Forms.ToolTip picInv3Tip;
        private System.Windows.Forms.ToolTip picInv4Tip;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.PictureBox picWeapon;
        private System.Windows.Forms.Label lblHeadgear;
    }
}