﻿namespace GameLibrary {
  public enum MoveDir {
    NO_MOVE,
    UP,
    DOWN,
    LEFT,
    RIGHT
  }
}